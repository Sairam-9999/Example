package com.Inforail;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InforailApplicationTests {

	@Test
	void contextLoads() {
	}

}
