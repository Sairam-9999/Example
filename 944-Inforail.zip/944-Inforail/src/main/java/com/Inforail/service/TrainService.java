package com.Inforail.service;


import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.Inforail.dto.TrainDTO;
import com.Inforail.entity.TrainEntity;
import com.Inforail.repo.TrainRepo;


@Service
public class TrainService {

	@Autowired
	TrainRepo trainRepo;
	@Autowired
	private Environment environment;
	
	public String createTrain(TrainDTO trainDTO) {
		
		TrainEntity trainEntity=TrainDTO.prepareTrainEntity(trainDTO);
		trainRepo.saveAndFlush(trainEntity);
		
		System.out.println("created train in TrainService.createTrain() for trainObj : "+trainDTO);
		return Integer.toString(trainEntity.getId());
	}
	
	public String updateTrain(String id, String fare) {
		
		Optional<TrainEntity> trainOptional=trainRepo.findById(Integer.parseInt(id));
		TrainEntity trainEntity=null;
		try {
			trainEntity=trainOptional.get();
			trainEntity.setFare(Double.parseDouble(fare));
			trainRepo.saveAndFlush(trainEntity);
		} catch (Exception e) {
			return environment.getProperty("train.fare.NotUpdated")+" : "+fare;
		}
		return environment.getProperty("train.fare.updated")+" : "+fare;
	}
	
	public List<TrainDTO> getRoutes(Integer id) {
		List<TrainEntity> getRoutes=trainRepo.findByRouteId(id);
		List<TrainDTO> getRoutesRes=new ArrayList<>();
		for(TrainEntity trainEntity : getRoutes)
			getRoutesRes.add(TrainDTO.prepareTrainDTO(trainEntity));
		return getRoutesRes;
	}
	
	
}
