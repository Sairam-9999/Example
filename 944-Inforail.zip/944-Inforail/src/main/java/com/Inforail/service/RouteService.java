package com.Inforail.service;

import java.util.List;
import java.util.Optional;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Inforail.dto.RouteDTO;
import com.Inforail.dto.TrainDTO;
import com.Inforail.entity.RouteEntity;
import com.Inforail.repo.RouteRepo;


@Service
public class RouteService {

	@Autowired
	RouteRepo routeRepo;
	
	public String createRoute(RouteDTO routeDTO) {
		RouteEntity routeEntity=RouteDTO.prepareRouteEntity(routeDTO);
		routeRepo.saveAndFlush(routeEntity);
		
		return routeEntity.getId()+"";
	}
	public RouteDTO fetchRoute(String idStr,List<TrainDTO> trainDTOs) {
		Integer id=Integer.parseInt(idStr);
		Optional<RouteEntity> en=routeRepo.findById(id);
		RouteDTO dto=null;
		if(en.isPresent()) {
			dto=RouteDTO.prepareRouteDTO(en.get());
			dto.setTrainList(trainDTOs);
		}
		
		System.out.println("returning from RouteService.fetchroute() for : "+id);
		return dto;
		
	}
	public List<TrainDTO> fetchTrain(String source,String destination) {
		System.out.println("returning from RouteService.fetchTrain() for : source : "+source+"\n Destination : "+destination);
		return null;
	}
	public RouteDTO updateRoute(String id,String source,String destination) {
		System.out.println("returning from RouteService.updateRoute() for : source : "+source+"\n Destination : "+destination);
		return null;
	}
	public RouteDTO updateRoute1(String id,RouteDTO routeDTO) {
		System.out.println("returning from RouteService.updateRoute1() for : route : "+routeDTO);
		
		return null;
	}
	public RouteDTO deleteTrain(String route,String train) {
		
		System.out.println("returning from RouteService.deleteTrain() for : route : "+route +" \n train : "+train);
		return null;
	}
}

