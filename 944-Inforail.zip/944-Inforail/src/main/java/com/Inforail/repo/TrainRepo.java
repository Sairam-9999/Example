package com.Inforail.repo;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Inforail.entity.TrainEntity;


public interface TrainRepo extends JpaRepository<TrainEntity,Integer>{
	
	public List<TrainEntity> findByRouteId(int id);
}

