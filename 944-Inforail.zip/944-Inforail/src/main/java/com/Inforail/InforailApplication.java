package com.Inforail;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.PropertySource;

@SpringBootApplication
@PropertySource(value = { "classpath:ValidationMessages.properties","classpath:application1.properties"})
public class InforailApplication {

	public static void main(String[] args) {
		SpringApplication.run(InforailApplication.class, args);
	}

}
